// Add Bus routes to the map
map.addLayer({
  id: 'layer2',
  type: 'line',
  source: {
    type: 'geojson',
    data: '../data/full_bus_routes.geojson'
  },
  paint: {
    'line-color': 'green',
    'line-width': 2
  }
});


// Add Bus routes show/hide button
const toggleRoutesButton = document.getElementById('toggle-routes');
let routesVisible = true;

toggleRoutesButton.addEventListener('click', () => {
if (routesVisible) {
  map.setLayoutProperty('layer2', 'visibility', 'none');
  routesVisible = false;
} else {
  map.setLayoutProperty('layer2', 'visibility', 'visible');
  routesVisible = true;
}
});

// Load Bus stop icons
map.loadImage(
    'bus.svg',
    function(error, image) {
        if (error) throw error;
        map.addImage('bus', image);
    }
);


// Add bus stop layer to the map
map.addLayer({
    id: 'bus-stops-layer',
    type: 'symbol',
    source: {
    type: 'geojson',
    data: '../data/bus_stops.geojson'
  },
    layout: {
            'icon-image': 'bus', // specify the Maki icon name
            'icon-size': 1.25,
            'text-field': '{stop_name}', // display the stop name as a label
            'text-offset': [0, 0.6],
            'text-anchor': 'top'
        }
});


// Add Bus stops show/hide button
const toggleStopsButton = document.getElementById('toggle-stops');
let stopsVisible = true;

toggleStopsButton.addEventListener('click', () => {
if (stopsVisible) {
  map.setLayoutProperty('bus-stops-layer', 'visibility', 'none');
  stopsVisible = false;
} else {
  map.setLayoutProperty('bus-stops-layer', 'visibility', 'visible');
  stopsVisible = true;
}
});