// Load the data
      d3.json("/repo/seneca_babcock.geojson").then(data => {
        
        // Create the projection
        const projection = d3.geoMercator()
          .center([-78.83563157282988, 42.871152398214576]) // Center on Buffalo, NY
          .scale(500000) // Set the scale of the map
          .translate([400, 300]); // Center the map in the SVG element


        // Create the path generator
        const path = d3.geoPath()
          .projection(projection);

       // Create the map
        const map = d3.select("#map")
  .selectAll("path")
  .data(data.features)
  .enter()
  .append("path")
  .attr("d", path)
  .attr("fill", d => d.properties.nbhdname === "Seneca Babcock" ? "blue" : "white")
  .attr("stroke", getComputedStyle(document.documentElement).getPropertyValue('--danger'))
  .attr("stroke-width", "3px")
  // ... // Set the stroke width to 2px
          .on("mouseover", (event, d) => {
            // Show the tooltip
            const tooltip = d3.select("#tooltip")
              .style("visibility", "visible")
              .text(d.properties.nbhdname);

            // Position the tooltip
            const x = event.pageX + 10;
            const y = event.pageY + 10;

            tooltip.style("left", x + "px")
                   .style("top", y + "px");

            // Save the tooltip reference to the path element
            d3.select(event.target)
              .attr("data-tooltip", "true")
              .attr("data-tooltip-id", tooltip.attr("id"));
          })
          .on("mousemove", event => {
            // Move the tooltip with the mouse
            const tooltip = d3.select("#tooltip");

            const x = event.pageX + 10;
            const y = event.pageY + 10;

            tooltip.style("left", x + "px")
                   .style("top", y + "px");
          })
          .on("mouseout", event => {
            // Hide the tooltip
            const tooltipId = d3.select(event.target)
              .attr("data-tooltip-id");

            d3.select(`#${tooltipId}`)
              .style("visibility", "hidden")
              .text("");

            // Remove the tooltip reference from the path element
            d3.select(event.target)
              .attr("data-tooltip", null)
              .attr("data-tooltip-id", null);
          });
      });