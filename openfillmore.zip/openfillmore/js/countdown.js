// Set the countdown date and time
const countdownDate = new Date("November 7, 2023 21:00:00 EST").getTime();

// Update the count down every 1 second
const countdownTimer = setInterval(function() {

// Get the current date and time
const now = new Date().getTime();

// Calculate the time difference
const time = (countdownDate - now) / 1000;

// Check if the countdown is over
if (time < 0) {
clearInterval(countdownTimer);
document.getElementById("countdown").innerHTML = "FINISHED!";
return;
}

// Convert time to days, hours, minutes, and seconds
const days = Math.floor(time / (60 * 60 * 24));
const hours = Math.floor((time % (60 * 60 * 24)) / (60 * 60));
const minutes = Math.floor((time % (60 * 60)) / 60);
const seconds = Math.floor(time % 60);

// Display the remaining time
document.getElementById("countdown").innerHTML = days + "d " + hours + "h "
+ minutes + "m " + seconds + "s ";

}, 1000);






