//neighborhood center coordinates
const nh_zoom = 15;

const nh_center = [
  { name: "allentown", lat:42.89856149879563, lng:-78.876099390827491, zoom: nh_zoom },
  { name: "broadway_fillmore", lat:42.887895641650928, lng:-78.83623404850006, zoom: nh_zoom },
  { name: "central", lat:42.885584222031682, lng:-78.882237613215864, zoom: nh_zoom },
  { name: "ellicott", lat:42.873828454284975, lng:-78.850371171290007, zoom: nh_zoom },
  { name: "elmwood_bryant", lat:42.904915882707108, lng:-78.874190147598014, zoom: nh_zoom },
  { name: "first_ward", lat:42.865921626961175, lng:-78.861987506120116, zoom: nh_zoom },
  { name: "genesee_moselle", lat:42.901740930321189, lng:-78.821286115454626, zoom: nh_zoom },
  { name: "lovejoy", lat:42.886683134876606, lng:-78.820557297954394, zoom: nh_zoom },
  { name: "lower_west", lat: 42.8916532472348, lng:-78.883551584256637, zoom: nh_zoom },
  { name: "seneca_babcock", lat:42.874857638072321, lng:-78.830314602966993, zoom: nh_zoom },
];

// Add event listeners to neighborhood links/icons
nh_center.forEach(neighborhood => {
  const icon = document.getElementById(neighborhood.name);
  icon.addEventListener('click', () => {
    map.flyTo({
      center: [neighborhood.lng, neighborhood.lat],
      zoom: neighborhood.zoom
    });
  });
});

// Add neighborhood boundary layers
nh_center.forEach(neighborhood => {
    const layerId = neighborhood.name;
    map.addSource(layerId, {
        'type': 'geojson',
        'data': 'repo/' + layerId + '.geojson'
    });
    map.addLayer({
        'id': layerId,
        'type': 'fill',
        'source': layerId,
        'paint': {
            'fill-color': 'yellow',
            'fill-opacity': 1
        },
        'layout': {
            'visibility': 'none'
        }
    });
});



function focusOnNeighborhood(neighborhoodName) {
    const neighborhood = nh_center.find(nh => nh.name === neighborhoodName);
    if (neighborhood) {
        // Fly to the neighborhood center
        map.flyTo({ center: [neighborhood.lng, neighborhood.lat], zoom: neighborhood.zoom });

        // Show the neighborhood boundary layer
        if (map.getLayer(neighborhoodName)) {
            map.setLayoutProperty(neighborhoodName, 'visibility', 'visible');
        }

        // Hide other neighborhood boundary layers
        nh_center.filter(nh => nh.name !== neighborhoodName).forEach(nh => {
            if (map.getLayer(nh.name)) {
                map.setLayoutProperty(nh.name, 'visibility', 'none');
            }
        });

        // Add outline layer if it doesn't exist
        const outlineLayerId = neighborhoodName + '-outline';
        if (!map.getLayer(outlineLayerId)) {
        map.addLayer({
        'id': outlineLayerId,
        'type': 'line',
        'source': {
            'type': 'geojson',
            'data': 'repo/' + neighborhoodName + '.geojson'
        },
        'paint': {
            'line-color': 'yellow',
            'line-opacity': 0.5,
            'line-width': 4
        }
        });
        } else {
        map.setLayoutProperty(outlineLayerId, 'visibility', 'visible');
        }


        // Hide outline layer of other neighborhoods
        nh_center.filter(nh => nh.name !== neighborhoodName).forEach(nh => {
            const layerId = nh.name + '-outline';
            if (map.getLayer(layerId)) {
                map.setLayoutProperty(layerId, 'visibility', 'none');
            }
        });
    }
}


