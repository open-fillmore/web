mapboxgl.accessToken = 'pk.eyJ1Ijoib3Blbi1maWxsbW9yZSIsImEiOiJjbGdhNTltbnoxZG45M2ZsaWY0bXM1YWYxIn0.C9c9heZXtdHp9kc8kPbpRA';

var map = new mapboxgl.Map({
  container: 'map',
  style: 'mapbox://styles/mapbox/dark-v10',
  center: [-78.856259, 42.877111],
  zoom: 14,
  pitch: 65, // Tilt the map
  bearing: 0, // Rotate the map to face north
  antialias: true, // Enable antialiasing for a smoother 3D look
  altitude: 1.5 // Adjust the altitude to control the 3D depth
});


// Load your GeoJSON file
map.on('load', function() {
  map.addSource('fillmore-district', {
    type: 'geojson',
    data: '../data/2024_fillmore.geojson'
  });



  // Add a fill layer for the entire map
  map.addLayer({
    id: 'background',
    type: 'fill',
    source: 'fillmore-district',
     paint: {
    'fill-color': 'rgba(255, 255, 255, 0.2)',
    'fill-opacity': 0.2
  }
  });

// Add a line layer to draw the polygon outline in red
map.addLayer({
  id: 'outline',
  type: 'line',
  source: 'fillmore-district',
  layout: { visibility: 'visible' },
  paint: {
    'line-color': 'red',
    'line-width': 5
  }
});




// Add 3D extrusion to the buildings layer
  map.addLayer({
    'id': 'buildings',
    'type': 'fill-extrusion',
    'source': {
      'type': 'vector',
      'url': 'mapbox://mapbox.mapbox-streets-v8'
    },
    'source-layer': 'building',
    'paint': {
      'fill-extrusion-color': '#DDBB99',
      'fill-extrusion-height': [
        'interpolate',
        ['linear'],
        ['zoom'],
         0, 0,
      14, ['*', 2, ['get', 'height']]
      ],
      'fill-extrusion-base': [
        'interpolate',
        ['linear'],
        ['zoom'],
        0, 0,
        14, ['get', 'min_height']
      ],
      'fill-extrusion-opacity': 0.7
    }
  });

// Add navigation control (zoom and rotation buttons)
var nav = new mapboxgl.NavigationControl({
  showCompass: true,
  showZoom: false,
  visualizePitch: true,
  visualPitch: {
    bearing: 0,
    pitch: 60,
    maxPitch: 60,
    minPitch: 0,
    pitchAlignment: 'auto'
  },
  compassStyle: 'rotate',
  showPitch: true,
  visualZoom: true,
  visualZoomStyle: 'zoom+',
  zoomInTitle: 'Zoom in',
  zoomOutTitle: 'Zoom out',
  pitchAdjustment: 10,
  bearingAdjustment: 15,
  customPitches: [0, 30, 60],
  customBearingSnap: 15,
  customBearingSnapListener: function(err) {
    console.log('Bearing snap listener:', err);
  },
  customZoomSnap: 0.25,
  customZoomSnapListener: function(err) {
    console.log('Zoom snap listener:', err);
  },
  customZoomSnapLevels: [{
    level: 0.25,
    snapThreshold: 0.05,
    maxPitch: 60,
    minPitch: 0
  }, {
    level: 0.5,
    snapThreshold: 0.1,
    maxPitch: 60,
    minPitch: 0
  }, {
    level: 1,
    snapThreshold: 0.2,
    maxPitch: 60,
    minPitch: 0
  }, {
    level: 2,
    snapThreshold: 0.25,
    maxPitch: 60,
    minPitch: 0
  }, {
    level: 3,
    snapThreshold: 0.5,
    maxPitch: 45,
    minPitch: 0
  }]
});


// Add the geocoder control
var geocoder = new MapboxGeocoder({
  accessToken: mapboxgl.accessToken,
  mapboxgl: mapboxgl,
  placeholder: "Search for an address",
  marker: false,
  flyTo: {
    zoom: 14,
  },
});


// When a result is selected from the geocoder, center the map on the result
geocoder.on("result", function (result) {
  map.flyTo({
    center: result.result.center,
    zoom: 16,
  });
});


// Update the search function to add the search result to the new layer
function geocode(searchInput) {
  var endpoint = 'https://api.mapbox.com/geocoding/v5/mapbox.places/' + encodeURIComponent(searchInput) + '.json?access_token=' + mapboxgl.accessToken;
  fetch(endpoint)
    .then(response => response.json())
    .then(data => {
      var searchResult = data.features[0];
      if (searchResult) {
        map.getSource('search-result').setData(searchResult);
        map.flyTo({
          center: searchResult.center,
          zoom: 15
        });
      }
    });
}

//add navigation controls to top left
map.addControl(nav, 'top-left');
map.addControl(geocoder, "top-left");
});




