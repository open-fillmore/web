# neighborhoods
Welcome to the Open Fillmore Neighborhood Repository.

This repository is a valuable resource for anyone interested in exploring the neighborhoods in the Fillmore district. The repository contains detailed GeoJSON and WKT files of each neighborhood, providing valuable geographic and spatial information that can be used for a variety of purposes.

WKT files are particularly useful in utilizing Socrata's within_polygon(...) function.


